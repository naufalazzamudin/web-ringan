import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import ExcelJS from 'exceljs';
import { createClient } from '@supabase/supabase-js';
import type { InventoryItem, PurchaseOrderItem, UserAccount, ActivityRecord, Category } from './src/lib/types';
import { isDateRepairedInMonth, parseMonthFilter, filterInventory, sortInventory, computeStats, MONTH_NAMES, formatDate, formatDateTime } from './src/lib/inventory-logic';
import { filterPurchaseOrders, sortPurchaseOrders, computePOStats } from './src/lib/po-logic';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Inisialisasi Supabase Client
const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_KEY || '';
if (!supabaseUrl || !supabaseKey) {
  console.warn("Peringatan: SUPABASE_URL atau SUPABASE_KEY belum dikonfigurasi di Environment Variables.");
}
const supabase = createClient(supabaseUrl, supabaseKey);

// In-memory sessions untuk mencatat user login sementara
const activeSessions = new Map<string, { user: UserAccount; expiresAt: number }>();
const secretTokens = new Set<string>();

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Helper untuk mencetak token otentikasi
function getAuthenticatedUser(req: Request): UserAccount | null {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '');
  const session = activeSessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return null;
  }
  return session.user;
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: 'Unauthorized. Please login.' });
    return;
  }
  (req as any).user = user;
  next();
}

// ========================
// AUTHENTICATION ROUTES
// ========================

// 1. Login (Mengecek ke tabel Supabase)
app.post('/api/auth/login', async (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password are required.' });
    return;
  }

  try {    
    const normalizedUser = username.trim().toUpperCase();
    
    // Ambil data user dari tabel 'users' Supabase
    const { data: foundUser, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', normalizedUser)
      .single();

    if (error || !foundUser) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    const isMatch = bcrypt.compareSync(password, foundUser.password_hash);
    if (!isMatch) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    const token = crypto.randomBytes(32).toString('hex');
    const userProfile: UserAccount = {
      id: foundUser.id,
      username: foundUser.username,
      role: foundUser.role,
      createdAt: foundUser.created_at,
      updatedAt: foundUser.updated_at
    };

    activeSessions.set(token, {
      user: userProfile,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 // 7 Hari
    });

    res.json({ token, user: userProfile });
  } catch (err) {
    res.status(500).json({ error: 'Database server error.' });
  }
});

// 2. Current User
app.get('/api/auth/me', (req: Request, res: Response) => {
  const user = getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: 'Unauthenticated' });
    return;
  }
  res.json({ user });
});

// 3. Logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.replace(/^Bearer\s+/i, '');
    activeSessions.delete(token);
  }
  res.json({ success: true });
});

// 4. Verify Secret Code
const SECRET_CODE = 'INNRATTAN.BJM';
app.post('/api/auth/verify-secret', (req: Request, res: Response) => {
  const { secretCode } = req.body;
  if (!secretCode || secretCode.trim() !== SECRET_CODE) {
    res.status(403).json({ error: 'Invalid secret code. Please try again.' });
    return;
  }
  const secretToken = crypto.randomBytes(24).toString('hex');
  secretTokens.add(secretToken);
  setTimeout(() => secretTokens.delete(secretToken), 30 * 60 * 1000);
  res.json({ success: true, secretToken });
});

// 5. Get Users List
app.get('/api/users', async (req: Request, res: Response) => {
  const secretToken = req.headers['x-secret-token'] as string;
  const user = getAuthenticatedUser(req);

  if (!secretToken && !user) {
    res.status(403).json({ error: 'Access denied. Secret code verification required.' });
    return;
  }

  const { data: allUsers, error } = await supabase.from('users').select('id, username, role, created_at, updated_at');
  if (error) {
    res.status(500).json({ error: 'Failed to fetch users from database.' });
    return;
  }
  
  const usersSafe = allUsers.map(u => ({
    id: u.id,
    username: u.username,
    role: u.role,
    createdAt: u.created_at,
    updatedAt: u.updated_at
  }));
  res.json({ users: usersSafe });
});

// 6. Update User Credentials
app.put('/api/users/:id', async (req: Request, res: Response) => {
  const secretToken = req.headers['x-secret-token'] as string;
  if (!secretToken || !secretTokens.has(secretToken)) {
    res.status(403).json({ error: 'Invalid or expired secret session.' });
    return;
  }

  const { id } = req.params;
  const { username, password } = req.body;

  try {
    const { data: oldUser } = await supabase.from('users').select('*').eq('id', id).single();
    if (!oldUser) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    let newUsername = oldUser.username;
    if (username && username.trim() !== '') {
      const trimmed = username.trim().toUpperCase();
      const { data: collision } = await supabase.from('users').select('id').eq('username', trimmed).not('id', 'eq', id).maybeSingle();
      if (collision) {
        res.status(400).json({ error: `Username ${trimmed} is already in use.` });
        return;
      }
      newUsername = trimmed;
    }

    let newHash = oldUser.password_hash;
    if (password && password.trim() !== '') {
      newHash = bcrypt.hashSync(password.trim(), 10);
    }

    const nowIso = new Date().toISOString();
    await supabase.from('users').update({
      username: newUsername,
      password_hash: newHash,
      updated_at: nowIso
    }).eq('id', id);

    for (const [token, session] of activeSessions.entries()) {
      if (session.user.id === id) {
        session.user.username = newUsername;
        session.user.updatedAt = nowIso;
      }
    }

    res.json({
      message: 'User credentials updated successfully.',
      user: { id, username: newUsername, role: oldUser.role, updatedAt: nowIso }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update user database.' });
  }
});

// ========================
// INVENTORY ROUTES
// ========================

// 7. Get Inventory List dengan filter dari database
app.get('/api/inventory', requireAuth, async (req: Request, res: Response) => {
  const { search, category, month, user, dateFrom, dateTo, sortBy, page = '1', limit = '50' } = req.query as Record<string, string>;

  // Ambil semua data dari Supabase terlebih dahulu untuk difilter oleh logika lokal Anda yang presisi
  const { data: allInventory, error } = await supabase.from('inventory').select('*');
  if (error || !allInventory) {
    res.status(500).json({ error: 'Failed to load inventory from cloud database.' });
    return;
  }

  // Petakan field snake_case Supabase ke camelCase aplikasi frontend Anda
  const mappedInventory: InventoryItem[] = allInventory.map(i => ({
    id: i.id,
    itemName: i.item_name,
    photoUrl: i.photo_url,
    category: i.category,
    dateRepaired: i.date_repaired,
    serialNumber: i.serial_number,
    remark: i.remark,
    createdAt: i.created_at,
    createdBy: i.created_by,
    updatedAt: i.updated_at,
    updatedBy: i.updated_by
  }));

  let filtered = filterInventory(mappedInventory, { search, category, month, user, dateFrom, dateTo });
  const sorted = sortInventory(filtered, (sortBy as any) || 'updated-newest');

  const pageNum = parseInt(page, 10) || 1;
  const limitNum = parseInt(limit, 10) || 50;
  const total = sorted.length;
  const startIndex = (pageNum - 1) * limitNum;
  const paginated = sorted.slice(startIndex, startIndex + limitNum);

  res.json({
    data: paginated,
    total,
    page: pageNum,
    totalPages: Math.ceil(total / limitNum) || 1
  });
});

// 8. Get Recently Edited Items
app.get('/api/inventory/recently-edited', requireAuth, async (req: Request, res: Response) => {
  const { data: invData } = await supabase.from('inventory').select('*').order('updated_at', { ascending: false }).limit(10);
  const { data: poData } = await supabase.from('purchase_orders').select('*').order('updated_at', { ascending: false }).limit(10);

  const allRecent: any[] = [];
  
  if (invData) {
    invData.forEach(i => {
      const mapped = { id: i.id, itemName: i.item_name, photoUrl: i.photo_url, category: i.category, dateRepaired: i.date_repaired, serialNumber: i.serial_number, remark: i.remark, createdAt: i.created_at, createdBy: i.created_by, updatedAt: i.updated_at, updatedBy: i.updated_by };
      allRecent.push({
        id: i.id, itemName: i.item_name, photoUrl: i.photo_url, categoryOrStatus: i.category, itemType: 'INVENTORY',
        dateRef: i.date_repaired, dateRefLabel: 'Tanggal dibereskan', serialOrQty: i.serial_number ? `SN: ${i.serial_number}` : 'SN: N/A',
		createdBy: i.created_by, updatedBy: i.updated_by, createdAt: i.created_at, updatedAt: i.updated_at, rawItem: mapped
});
});
}
if (poData) {
poData.forEach(p => {
const mapped = { id: p.id, itemName: p.item_name, photoUrl: p.photo_url, dateOrder: p.date_order, dateArrival: p.date_arrival, quantity: p.quantity, forUse: p.for_use, remarks: p.remarks, status: p.status, createdAt: p.created_at, createdBy: p.created_by, updatedAt: p.updated_at, updatedBy: p.updated_by };
allRecent.push({
id: p.id, itemName: p.item_name, photoUrl: p.photo_url, categoryOrStatus: p.status, itemType: 'PURCHASE ORDER',
dateRef: p.date_order, dateRefLabel: 'Tanggal order', serialOrQty: ${p.quantity} Unit   ${p.for_use},
createdBy: p.created_by, updatedBy: p.updated_by, createdAt: p.created_at, updatedAt: p.updated_at, rawItem: mapped
});
});
}
allRecent.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
res.json({ data: allRecent.slice(0, 10) });
});
// 9. Get Dashboard Stats
app.get('/api/inventory/stats', requireAuth, async (req: Request, res: Response) => {
const { data: allInv } = await supabase.from('inventory').select('*');
const mapped: InventoryItem[] = (allInv || []).map(i => ({
id: i.id, itemName: i.item_name, photoUrl: i.photo_url, category: i.category, dateRepaired: i.date_repaired,
serialNumber: i.serial_number, remark: i.remark, createdAt: i.created_at, createdBy: i.created_by, updatedAt: i.updated_at, updatedBy: i.updated_by
}));
res.json(computeStats(mapped, new Date()));
});
// 10. Get Recent Activities
app.get('/api/inventory/recent-activity', requireAuth, async (req: Request, res: Response) => {
const { data: acts } = await supabase.from('activities').select('*').order('timestamp', { ascending: false }).limit(15);
const mapped = (acts || []).map(a => ({
id: a.id, targetId: a.target_id, inventoryId: a.inventory_id, itemName: a.item_name, category: a.category, type: a.type, action: a.action, username: a.username, timestamp: a.timestamp
}));
res.json({ data: mapped });
});
// 11. Add New Inventory
app.post('/api/inventory', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { itemName, photoUrl, category, dateRepaired, serialNumber, remark } = req.body;
const nowIso = new Date().toISOString();
const id = inv-${Date.now()}-${Math.floor(Math.random() * 1000)};
const { error } = await supabase.from('inventory').insert({
id, item_name: itemName, photo_url: photoUrl, category, date_repaired: dateRepaired,
serial_number: serialNumber || null, remark: remark || null, created_at: nowIso, created_by: user.username, updated_at: nowIso, updated_by: user.username
});
if (error) return res.status(500).json({ error: 'Failed to insert data to database cloud.' });
await supabase.from('activities').insert({
id: act-${Date.now()}, inventory_id: id, item_name: itemName, category, action: 'Added', username: user.username, timestamp: nowIso
});
res.status(201).json({ message: 'Inventory added successfully.', data: { id, itemName, photoUrl, category, dateRepaired, serialNumber, remark, createdAt: nowIso, createdBy: user.username, updatedAt: nowIso, updatedBy: user.username } });
});
// 12. Update Inventory
app.put('/api/inventory/:id', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { id } = req.params;
const { itemName, photoUrl, category, dateRepaired, serialNumber, remark } = req.body;
const nowIso = new Date().toISOString();
const { error } = await supabase.from('inventory').update({
item_name: itemName, photo_url: photoUrl, category, date_repaired: dateRepaired,
serial_number: serialNumber || null, remark: remark || null, updated_at: nowIso, updated_by: user.username
}).eq('id', id);
if (error) return res.status(500).json({ error: 'Failed to update database cloud.' });
await supabase.from('activities').insert({
id: act-${Date.now()}, inventory_id: id, item_name: itemName, category, action: 'Edited', username: user.username, timestamp: nowIso
});
res.json({ message: 'Inventory updated successfully.', data: { id, itemName, photoUrl, category, dateRepaired, serialNumber, remark, updatedAt: nowIso, updatedBy: user.username } });
});
// 13. Delete Inventory
app.delete('/api/inventory/:id', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { id } = req.params;
const { data: item } = await supabase.from('inventory').select('*').eq('id', id).single();
if (!item) return res.status(404).json({ error: 'Item not found.' });
await supabase.from('inventory').delete().eq('id', id);
await supabase.from('activities').insert({
id: act-${Date.now()}, inventory_id: id, item_name: item.item_name, category: item.category, action: 'Deleted', username: user.username, timestamp: new Date().toISOString()
});
res.json({ message: 'Inventory item deleted successfully.' });
});
// ===========================================
// 14. Upload Photo dialihkan ke Supabase Storage
// ===========================================
app.post('/api/upload', requireAuth, async (req: Request, res: Response) => {
try {
const { imageBase64 } = req.body;
if (!imageBase64) return res.status(400).json({ error: 'Image data is required.' });
const matches = imageBase64.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
let buffer: Buffer;
let ext = 'jpg';
if (matches && matches.length === 3) {
ext = matches[1].split('/')[1] === 'jpeg' ? 'jpg' : matches[1].split('/')[1];
buffer = Buffer.from(matches[2], 'base64');
} else {
buffer = Buffer.from(imageBase64, 'base64');
}
const uniqueName = upload-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext};
// Unggah file biner langsung ke bucket Supabase bernama 'uploads'
const { data, error } = await supabase.storage
.from('uploads')
.upload(uniqueName, buffer, {
contentType: image/${ext},
upsert: true
});
if (error) throw error;
// Ambil URL publik file yang berhasil diupload
const { data: publicUrlData } = supabase.storage.from('uploads').getPublicUrl(uniqueName);
res.json({ url: publicUrlData.publicUrl });
} catch (err: any) {
console.error('Upload error:', err);
res.status(500).json({ error: 'Failed to upload image to Supabase Storage.' });
}
});
// ========================
// PURCHASE ORDER ROUTES
// ========================
// 15. Get Purchase Orders
app.get('/api/po', requireAuth, async (req: Request, res: Response) => {
const { search, status, month, user, dateFrom, dateTo, sortBy, page = '1', limit = '50' } = req.query as Record<string, string>;
const { data: poData } = await supabase.from('purchase_orders').select('*');
const mapped: PurchaseOrderItem[] = (poData || []).map(p => ({
id: p.id, itemName: p.item_name, photoUrl: p.photo_url, dateOrder: p.date_order, dateArrival: p.date_arrival,
quantity: p.quantity, forUse: p.for_use, remarks: p.remarks, status: p.status, createdAt: p.created_at, createdBy: p.created_by, updatedAt: p.updated_at, updatedBy: p.updated_by
}));
const filtered = filterPurchaseOrders(mapped, { search, status: status as any, month, user, dateFrom, dateTo });
const sorted = sortPurchaseOrders(filtered, (sortBy as any) || 'updated-newest');
const pageNum = parseInt(page, 10) || 1;
const limitNum = parseInt(limit, 10) || 50;
const total = sorted.length;
const startIndex = (pageNum - 1) * limitNum;
const paginated = sorted.slice(startIndex, startIndex + limitNum);
res.json({ data: paginated, total, page: pageNum, totalPages: Math.ceil(total / limitNum) || 1 });
});
// 16. Get PO Stats
app.get('/api/po/stats', requireAuth, async (req: Request, res: Response) => {
const { data: poData } = await supabase.from('purchase_orders').select('*');
const mapped: PurchaseOrderItem[] = (poData || []).map(p => ({
id: p.id, itemName: p.item_name, photoUrl: p.photo_url, dateOrder: p.date_order, dateArrival: p.date_arrival,
quantity: p.quantity, forUse: p.for_use, remarks: p.remarks, status: p.status, createdAt: p.created_at, createdBy: p.created_by, updatedAt: p.updated_at, updatedBy: p.updated_by
}));
res.json(computePOStats(mapped, new Date()));
});
// 17. Add Purchase Order
app.post('/api/po', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { itemName, photoUrl, dateOrder, dateArrival, quantity, forUse, remarks, status } = req.body;
const nowIso = new Date().toISOString();
const id = po-${Date.now()}-${Math.floor(Math.random() * 1000)};
await supabase.from('purchase_orders').insert({
id, item_name: itemName, photo_url: photoUrl, date_order: dateOrder, date_arrival: dateArrival || null,
quantity, for_use: forUse, remarks: remarks || null, status, created_at: nowIso, created_by: user.username, updated_at: nowIso, updated_by: user.username
});
await supabase.from('activities').insert({
id: act-${Date.now()}, target_id: id, item_name: itemName, category: 'PURCHASE ORDER', type: 'PURCHASE ORDER', action: 'Added', username: user.username, timestamp: nowIso
});
res.status(201).json({ message: 'Purchase Order added successfully.', data: { id, itemName, photoUrl, dateOrder, dateArrival, quantity, forUse, remarks, status } });
});
// 18. Update Purchase Order
app.put('/api/po/:id', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { id } = req.params;
const { itemName, photoUrl, dateOrder, dateArrival, quantity, forUse, remarks, status } = req.body;
const nowIso = new Date().toISOString();
await supabase.from('purchase_orders').update({
item_name: itemName, photo_url: photoUrl, date_order: dateOrder, date_arrival: dateArrival || null,
quantity, for_use: forUse, remarks: remarks || null, status, updated_at: nowIso, updated_by: user.username
}).eq('id', id);
await supabase.from('activities').insert({
id: act-${Date.now()}, target_id: id, item_name: itemName, category: 'PURCHASE ORDER', type: 'PURCHASE ORDER', action: 'Edited', username: user.username, timestamp: nowIso
});
res.json({ message: 'Purchase Order updated successfully.' });
});
// 19. Delete Purchase Order
app.delete('/api/po/:id', requireAuth, async (req: Request, res: Response) => {
const user = (req as any).user as UserAccount;
const { id } = req.params;
const { data: item } = await supabase.from('purchase_orders').select('*').eq('id', id).single();
if (!item) return res.status(404).json({ error: 'Purchase Order not found.' });
await supabase.from('purchase_orders').delete().eq('id', id);
await supabase.from('activities').insert({
id: act-${Date.now()}, target_id: id, item_name: item.item_name, category: 'PURCHASE ORDER', type: 'PURCHASE ORDER', action: 'Deleted', username: user.username, timestamp: new Date().toISOString()
});
res.json({ message: 'Purchase Order deleted successfully.' });
});
// 20 & 21. Export Excel tetap bekerja secara penuh (mengambil data stream dari Cloud Supabase)
app.get('/api/export/excel', requireAuth, async (req: Request, res: Response) => {
// Logika pembuatan excel menggunakan library exceljs berjalan dengan mengambil data dari Supabase
try {
const { month, category, user, search } = req.query as Record<string, string>;
const { data: allInv } = await supabase.from('inventory').select('*');
const mapped: InventoryItem[] = (allInv || []).map(i => ({
id: i.id, itemName: i.item_name, photoUrl: i.photo_url, category: i.category, dateRepaired: i.date_repaired,
serialNumber: i.serial_number, remark: i.remark, createdAt: i.created_at, createdBy: i.created_by, updatedAt: i.updated_at, updatedBy: i.updated_by
}));
const itemsToExport = sortInventory(filterInventory(mapped, { month, category, user, search }), 'date-newest');
const workbook = new ExcelJS.Workbook();
const sheet = workbook.addWorksheet('INVENTORY');
sheet.columns = [{ header: 'Nama Barang', key: 'name', width: 30 }, { header: 'Kategori', key: 'cat', width: 20 }, { header: 'Tanggal Dibereskan', key: 'date', width: 20 }];
itemsToExport.forEach(item => sheet.addRow({ name: item.itemName, cat: item.category, date: formatDate(item.dateRepaired) }));
res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
res.setHeader('Content-Disposition', 'attachment; filename="HOTEL_IT_INVENTORY.xlsx"');
await workbook.xlsx.write(res);
res.end();
} catch (err) {
res.status(500).json({ error: 'Failed to generate Excel.' });
}
});
app.get('/api/export/excel-po', requireAuth, async (req: Request, res: Response) => {
try {
const { month, status, user, search } = req.query as Record<string, string>;
const { data: poData } = await supabase.from('purchase_orders').select('*');
const mapped: PurchaseOrderItem[] = (poData || []).map(p => ({
id: p.id, itemName: p.item_name, photoUrl: p.photo_url, dateOrder: p.date_order, dateArrival: p.date_arrival,
quantity: p.quantity, forUse: p.for_use, remarks: p.remarks, status: p.status, createdAt: p.created_at, createdBy: p.created_by, updatedAt: p.updated_at, updatedBy: p.updated_by
}));
const itemsToExport = sortPurchaseOrders(filterPurchaseOrders(mapped, { month, status: status as any, user, search }), 'order-newest');
const workbook = new ExcelJS.Workbook();
const sheet = workbook.addWorksheet('PURCHASE_ORDERS');
sheet.columns = [{ header: 'Item Name', key: 'name', width: 30 }, { header: 'Qty', key: 'qty', width: 10 }, { header: 'Status', key: 'status', width: 15 }];
itemsToExport.forEach(p => sheet.addRow({ name: p.itemName, qty: p.quantity, status: p.status }));
res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
res.setHeader('Content-Disposition', 'attachment; filename="HOTEL_IT_PURCHASE_ORDER.xlsx"');
await workbook.xlsx.write(res);
res.end();
} catch (err) {
res.status(500).json({ error: 'Failed to generate Excel.' });
}
});
async function startServer() {
if (process.env.NODE_ENV !== 'production') {
const vite = await createViteServer({
server: { middlewareMode: true },
appType: 'spa'
});
app.use(vite.middlewares);
} else {
const distPath = path.resolve(process.cwd(), 'dist');
app.use(express.static(distPath));
app.get('*', (req, res) => {
res.sendFile(path.resolve(distPath, 'index.html'));
});
}
app.listen(PORT, '0.0.0.0', () => {
console.log(Server running at http://0.0.0:${PORT});
});
}
startServer();