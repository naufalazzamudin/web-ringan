import React, { useState } from 'react';
import { Settings, Shield, User, HardDrive, LogOut, Sun, Moon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SettingsViewProps {
  onLogout: () => void;
  onOpenUserManagement: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onLogout, onOpenUserManagement }) => {
  const { user } = useAuth();
  const [theme, setTheme] = useState<'light' | 'system'>('light');

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider mb-1">
          <Settings className="w-4 h-4" />
          <span>Application Preferences</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          SYSTEM SETTINGS
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          General application details and staff configuration
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-2xs space-y-6">
        {/* App Info */}
        <div className="pb-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-slate-900">Application Name</div>
            <div className="text-xs text-slate-500 mt-0.5">Hotel IT Department Inventory Management System</div>
          </div>
          <span className="px-3 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-lg border border-indigo-100">
            v1.0.0 Stable
          </span>
        </div>

        {/* Current User */}
        <div className="pb-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">{user?.username}</div>
              <div className="text-xs text-slate-500">{user?.role}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenUserManagement}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors"
          >
            Manage Credentials
          </button>
        </div>

        {/* Theme preference */}
        <div className="pb-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="text-sm font-bold text-slate-900">Theme Preference</div>
            <div className="text-xs text-slate-500 mt-0.5">Hotel IT Professional Clean Light theme</div>
          </div>
          <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200">
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                theme === 'light' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-600'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Light</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme('system')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                theme === 'system' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-600'
              }`}
            >
              <Moon className="w-3.5 h-3.5 text-indigo-500" />
              <span>System</span>
            </button>
          </div>
        </div>

        {/* Storage & Persistence Status */}
        <div className="pb-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">Persistent Storage Status</div>
              <div className="text-xs text-emerald-600 font-semibold">Active & Synced to Server Database</div>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono">data/db.json</span>
        </div>

        {/* Logout */}
        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-bold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Current User</span>
          </button>
        </div>
      </div>
    </div>
  );
};
